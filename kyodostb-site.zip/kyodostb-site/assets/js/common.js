//スムーススクロール
$('a[href^="#"]').click(function () {
	const speed = 600;
	let href = $(this).attr("href");
	let target = $(href == "#" || href == "" ? "html" : href);
	let position = target.offset().top;
	$("body,html").animate({ scrollTop: position }, speed, "swing");
	return false;
});

// スマホヘッダーメニュー
$(function () {
	$('.humburgerBtn').on('click', function () {
		$(this).toggleClass('open');

		if ($('.headMenu').is(':visible')) {
			$('.headMenu').fadeOut(400); // ふわっと非表示
		} else {
			$('.headMenu').fadeIn(400);  // ふわっと表示
		}
	});
});

$(function () {
	$('.navList__toggle').on('click', function () {
		var parent = $(this).closest('.parentLink');
		parent.toggleClass('open');
		parent.find('.childList').slideToggle(200);
	});
});


// スライダー
$(document).ready(function () {
	$('.slider').slick({
		autoplay: true,
		slidesToShow: 1,
		fade: true,
		arrows: false,
		speed: 2500,
		pauseOnFocus: false,
		pauseOnHover: false,
		pauseOnDotsHover: false
	});
});


// スクロールで左右からコンテンツが現れる
$(function () {
	$(window).on('scroll', function () {
		$('.slide-left, .slide-right').each(function () {
			var elemPos = $(this).offset().top;
			var scroll = $(window).scrollTop();
			var windowHeight = $(window).height();
			if (scroll > elemPos - windowHeight + 200) {
				$(this).addClass('slideIn');
			}
		});
	});
});


// スクロールでンテンツがふわっと現れる
$(window).on('scroll', function () {
	$('.fadeIn__item').each(function () {
		var elemPos = $(this).offset().top;
		var scroll = $(window).scrollTop();
		var windowHeight = $(window).height();
		if (scroll > elemPos - windowHeight + 200) {
			$(this).addClass('fadeIn');
		}
	});
});

// カーソル変更
$(function () {
	// スマホサイズ（768px以下）ではコードを無効にする
    if (window.innerWidth <= 768) {
        return; // 何もしない
    }

	//カーソル要素の指定
	var cursor = $("#cursor");
	//ちょっと遅れてついてくるストーカー要素の指定  
	var stalker = $("#stalker");

	//mousemoveイベントでカーソル要素を移動させる
	$(document).on("mousemove", function (e) {
		//カーソルの座標位置を取得
		var x = e.clientX;
		var y = e.clientY;
		//カーソル要素のcssを書き換える用
		cursor.css({
			"opacity": "0.9",
			"top": y + "px",
			"left": x + "px"
		});
		//ストーカー要素のcssを書き換える用    
		setTimeout(function () {
			stalker.css({
				"opacity": "0.4",
				"top": y + "px",
				"left": x + "px"
			});
		}, 140);//カーソルより遅れる時間を指定
	});
	//aタグホバー
	$("a").on({
		"mouseenter": function () {
			//activeクラス付与
			cursor.addClass("active");
			stalker.addClass("active");
		},
		"mouseleave": function () {
			cursor.removeClass("active");
			stalker.removeClass("active");

		}
	});
});