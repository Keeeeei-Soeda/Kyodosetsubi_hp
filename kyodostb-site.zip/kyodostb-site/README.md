# kyodostb.co.jp 静的ミラー（作り直し用リファレンス）

取得日: 2026-09-30
取得元: https://kyodostb.co.jp/

公開ページのHTML・CSS・JS・画像を、元サイトと同じパス構成で保存したものです。
作り直しの参照用で、PHPテンプレート・管理画面設定・フォーム処理（MW WP Form）は含みません。

## 確認方法

リポジトリ直下で静的サーバーを起動してください（URLはルート相対に書き換え済みです）。

```bash
npx serve .
```

## 元サイトの構成

- WordPress（CMSは /cms/ 配下、独自テーマ kyodostb）
- jQuery 3.7.1 / slick（スライダー）
- プラグイン: XO Event Calendar, WP-PageNavi, MW WP Form
- 共通CSS: assets/css/base.css, page.css ／ ページ別CSS: assets/css/page-*.css
- 共通JS: assets/js/common.js

## ページ一覧

| URL | ファイル |
|---|---|
| / | index.html |
| /company/ | company/index.html |
| /works/ | works/index.html |
| /recruit/ | recruit/index.html |
| /recruit/company/ | recruit/company/index.html |
| /assist/ | assist/index.html |
| /contact/ | contact/index.html |
| /news/ | news/index.html |
| /post-241/ | post-241/index.html |
| /post-150/ | post-150/index.html |
| /post-1/ | post-1/index.html |
| /sitemap/ | sitemap/index.html |
| /privacypolicy/ | privacypolicy/index.html |
| /recruit/member01 | recruit/member01/index.html |
| /recruit/member02 | recruit/member02/index.html |
| /recruit/member03 | recruit/member03/index.html |
| /recruit/member04 | recruit/member04/index.html |
| /recruit/member05 | recruit/member05/index.html |
| /news/?slug=news | news/category-news/index.html |
| /news/?slug=recruit | news/category-recruit/index.html |
| /news/?slug=blog | news/category-blog/index.html |
| /work/ | work/index.html |
| /recruit/member/ | recruit/member/index.html |

## 取得できなかったもの

- slick のフォント・ローディング画像（元サイトでも404）
- Google Tag Manager（外部）
- /https://www.nohmi.co.jp/ （元サイトのリンク誤り。外部リンクが相対パスになっている）
